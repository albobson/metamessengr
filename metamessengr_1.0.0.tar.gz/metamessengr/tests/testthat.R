library(testthat)
library(metamessengr)

test_check("metamessengr")
