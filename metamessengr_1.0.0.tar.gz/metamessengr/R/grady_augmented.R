#' Grady-Augmented Dictionary Words
#'
#' @docType data
#'
#' @usage data(grady_augmented)
#'
#' @format A character vector with 122806 elements.
#'
#' @keywords datasets
#'
#' @source Taken from the Lexicon package
"grady_augmented"
